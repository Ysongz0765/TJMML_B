from __future__ import annotations

"""Q1 v1.2 mathematical-modeling core.

This derivative module was mechanically extracted from ``src/q1/run_q1_v12.py``.
The listed mathematical function bodies are verbatim, with their required
numerical imports and original constants.
"""

import os
from typing import Any

import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import kendalltau, spearmanr

from .bt_model import fit_dimensions
from .config import CORE_MODELS, KIMI_MODEL_ID, MAIN_LAMBDA, MARGIN_EPSILON
from .correlations import family_representation, missing_aware_spearman
from .dimension_weights import information_factor, non_redundancy_factors
from .load_data import Q1Data
from .pairwise import build_pairwise, graph_diagnostics


RANDOM_SEED = 20260817
BOOTSTRAP_B = int(os.environ.get("Q1_V12_BOOTSTRAP_B", "2000"))

TYPE_C_MODELS = {
    "kimi_k3_max",
    "gpt_5_6_sol_max",
    "gpt_5_5_xhigh",
    "claude_fable_5_max",
    "claude_opus_4_8_max",
    "gemini_3_1_pro_high",
    "qwen3_8_max",
}
TYPE_A_MODELS = {"deepseek_v4_pro_max", "deepseek_v4_flash_max", "glm_5_2_max"}


def dim_code(dimension: str) -> str:
    return dimension.split(" ", 1)[0]

def c5_audit(q1: Q1Data) -> pd.DataFrame:
    c5 = q1.long[q1.long["dimension"].str.startswith("C5")]
    rows = []
    for model_id in CORE_MODELS:
        name = q1.model_names[model_id]
        observed = set(c5.loc[(c5["model_id"] == model_id) & c5["score"].notna(), "benchmark_family"])
        if model_id in TYPE_C_MODELS:
            capable: bool | str = True
            kind = "Type C: NORMAL_OBSERVATION"
            rule = "Use observed C5 Bradley-Terry score as S_i5*."
            evidence = "Frozen C5 observation(s): " + ", ".join(sorted(observed))
        elif model_id in TYPE_A_MODELS:
            capable = False
            kind = "Type A: STRUCTURAL_CAPABILITY_ABSENCE"
            rule = "Benchmark scores remain NA; set capability availability A_i=0 and S_i5*=0 only for the overall capability system."
            if model_id == "glm_5_2_max":
                evidence = "Manual capability verification v1.2; reviewer-confirmed GLM-5.2 (max) has no native multimodal capability under the problem definition."
            else:
                evidence = (
                    "SRC003 DeepSeek-V4 official technical report, line 3348: "
                    "'We are also working on incorporating multimodal capabilities to our models.'"
                )
        else:
            capable = False
            kind = "Type A: STRUCTURAL_CAPABILITY_ABSENCE"
            rule = "Benchmark scores remain NA; set capability availability A_i=0 and S_i5*=0 only for the overall capability system."
            evidence = (
                "Manual capability verification v1.2; official GLM-5.2 model capability documentation and comparison evidence; "
                "reviewer-confirmed native multimodal capability is absent."
            )
        if model_id in TYPE_C_MODELS:
            mmmu = "OBSERVED" if "MMMU-Pro" in observed else "BENCHMARK_MISSING"
            mathvision = "OBSERVED" if "MathVision" in observed else "BENCHMARK_MISSING"
        elif model_id in TYPE_A_MODELS:
            mmmu = mathvision = "NOT_APPLICABLE_CAPABILITY_ABSENCE"
        else:
            mmmu = mathvision = "NOT_APPLICABLE_CAPABILITY_ABSENCE"
        rows.append(
            {
                "model_id": model_id,
                "model": name,
                "multimodal_capable": capable,
                "C5_applicability_type": kind,
                "MMMU_Pro_status": mmmu,
                "MathVision_status": mathvision,
                "evidence_source": evidence,
                "handling_rule": rule,
            }
        )
    return pd.DataFrame(rows)

def fit_main(q1: Q1Data, long: pd.DataFrame) -> dict[str, Any]:
    pairwise = build_pairwise(long, margin_method="range", epsilon_m=MARGIN_EPSILON)
    scores, diag = fit_dimensions(pairwise, q1.dimensions, CORE_MODELS, MAIN_LAMBDA)
    return {"pairwise": pairwise, "scores": scores, "diag": diag}

def score_matrix(scores: pd.DataFrame, dimensions: list[str]) -> pd.DataFrame:
    matrix = scores.set_index("model_id")[[f"{d}_score" for d in dimensions]].copy()
    matrix.columns = [dim_code(d) for d in dimensions]
    return matrix

def theta_matrix(scores: pd.DataFrame, dimensions: list[str]) -> pd.DataFrame:
    matrix = scores.set_index("model_id")[[f"{d}_theta" for d in dimensions]].copy()
    matrix.columns = [dim_code(d) for d in dimensions]
    return matrix

def perspective_matrix(scores: pd.DataFrame, dimensions: list[str], perspective: str) -> pd.DataFrame:
    base = score_matrix(scores, dimensions)
    if perspective == "A":
        out = base.loc[CORE_MODELS, ["C1", "C2", "C3", "C4", "C5"]].copy()
        out.loc[list(TYPE_A_MODELS), "C5"] = 0.0
        return out
    if perspective == "B":
        return base.loc[CORE_MODELS, ["C1", "C2", "C3", "C4"]].copy()
    if perspective == "C":
        return base.loc[[m for m in CORE_MODELS if m in TYPE_C_MODELS], ["C1", "C2", "C3", "C4", "C5"]].copy()
    raise ValueError(perspective)

def stability_from_boot_theta(
    main_theta: pd.DataFrame,
    boot_theta_long: pd.DataFrame,
    model_subset: list[str],
    dimensions: list[str],
) -> tuple[dict[str, float], pd.DataFrame]:
    rows = []
    factors: dict[str, float] = {}
    for dim in dimensions:
        code = dim_code(dim)
        reference = main_theta.loc[main_theta.index.intersection(model_subset), code].dropna()
        rhos = []
        for _, group in boot_theta_long[boot_theta_long["dimension"] == code].groupby("bootstrap"):
            candidate = group.set_index("model_id")["theta"]
            common = reference.index.intersection(candidate.dropna().index)
            if len(common) >= 3 and reference.loc[common].nunique() > 1 and candidate.loc[common].nunique() > 1:
                rho = spearmanr(reference.loc[common], candidate.loc[common]).correlation
                if np.isfinite(rho):
                    rhos.append(float(rho))
        median_rho = float(np.median(rhos)) if rhos else np.nan
        stability = float((1.0 + median_rho) / 2.0) if np.isfinite(median_rho) else 0.5
        factors[code] = stability
        rows.append(
            {
                "perspective_dimension": code,
                "valid_bootstrap_replicates": len(rhos),
                "median_spearman_theta_rank": median_rho,
                "latent_ranking_stability_T": stability,
            }
        )
    return factors, pd.DataFrame(rows)

def objective_weights(matrix: pd.DataFrame, stability: dict[str, float]) -> pd.DataFrame:
    info = {c: information_factor(matrix[c]) for c in matrix.columns}
    nonred = non_redundancy_factors(matrix)
    rows = []
    for code in matrix.columns:
        raw = info[code] * nonred[code] * stability[code]
        rows.append(
            {
                "dimension": code,
                "information_I": info[code],
                "non_redundancy_R": nonred[code],
                "latent_rank_stability_T": stability[code],
                "q": raw,
            }
        )
    out = pd.DataFrame(rows)
    total = float(out["q"].sum())
    out["weight"] = out["q"] / total if total > 0 else 1.0 / len(out)
    return out

def rank_matrix(matrix: pd.DataFrame, weights: pd.DataFrame, q1: Q1Data, label: str) -> pd.DataFrame:
    if matrix.isna().any(axis=None):
        bad = matrix.index[matrix.isna().any(axis=1)].tolist()
        raise ValueError(f"{label} contains incomplete rows: {bad}")
    weight_map = weights.set_index("dimension")["weight"].reindex(matrix.columns)
    scores = matrix.mul(weight_map, axis=1).sum(axis=1)
    out = matrix.copy()
    # The matrix index is the model id; clear its name before adding the
    # explicit model_id column so pandas does not see an ambiguous label.
    out.index.name = None
    out.insert(0, "model", [q1.model_names[m] for m in out.index])
    out.insert(0, "model_id", out.index)
    out["overall_score"] = scores
    out = out.sort_values(["overall_score", "model_id"], ascending=[False, True]).reset_index(drop=True)
    out.insert(0, "rank", np.arange(1, len(out) + 1))
    out["ranking_perspective"] = label
    return out

def rank_comparison(main: pd.DataFrame, other: pd.DataFrame, label: str) -> dict[str, Any]:
    merged = main[["model_id", "rank"]].merge(other[["model_id", "rank"]], on="model_id", suffixes=("_A", "_other"))
    rho = spearmanr(merged["rank_A"], merged["rank_other"]).correlation if len(merged) >= 3 else np.nan
    tau = kendalltau(merged["rank_A"], merged["rank_other"]).correlation if len(merged) >= 3 else np.nan
    a_top3 = set(main.nsmallest(3, "rank")["model_id"])
    o_top3 = set(other.nsmallest(3, "rank")["model_id"])
    kimi_a = main.loc[main["model_id"] == KIMI_MODEL_ID, "rank"]
    kimi_o = other.loc[other["model_id"] == KIMI_MODEL_ID, "rank"]
    return {
        "comparison": label,
        "common_models": len(merged),
        "spearman": float(rho) if np.isfinite(rho) else np.nan,
        "kendall_tau": float(tau) if np.isfinite(tau) else np.nan,
        "kimi_rank_A": int(kimi_a.iloc[0]) if len(kimi_a) else np.nan,
        "kimi_rank_other": int(kimi_o.iloc[0]) if len(kimi_o) else np.nan,
        "top3_overlap_count": len(a_top3 & o_top3),
        "top3_membership_A": "; ".join(sorted(a_top3)),
        "top3_membership_other": "; ".join(sorted(o_top3)),
    }

def parametric_bootstrap(
    q1: Q1Data,
    pairwise: pd.DataFrame,
    main_scores: pd.DataFrame,
    b: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(RANDOM_SEED)
    main_theta = theta_matrix(main_scores, q1.dimensions)
    p = []
    for row in pairwise.itertuples(index=False):
        code = dim_code(row.dimension)
        delta = main_theta.loc[row.model_i, code] - main_theta.loc[row.model_j, code]
        p.append(float(expit(delta)))
    p = np.asarray(p)
    theta_rows = []
    score_rows = []
    convergence_rows = []
    for iteration in range(1, b + 1):
        boot_pairwise = pairwise.copy()
        boot_pairwise["y"] = rng.binomial(1, p).astype(float)
        scores, diag = fit_dimensions(boot_pairwise, q1.dimensions, CORE_MODELS, MAIN_LAMBDA)
        for dim in q1.dimensions:
            code = dim_code(dim)
            for row in scores[["model_id", f"{dim}_theta", f"{dim}_score"]].itertuples(index=False):
                theta_rows.append({"bootstrap": iteration, "dimension": code, "model_id": row[0], "theta": row[1]})
                score_rows.append({"bootstrap": iteration, "dimension": code, "model_id": row[0], "score": row[2]})
            convergence_rows.append(
                {
                    "bootstrap": iteration,
                    "dimension": code,
                    "converged": bool(diag[dim]["converged"]),
                    "message": diag[dim]["message"],
                }
            )
        if iteration % 100 == 0:
            print(f"q1_v1.2 bootstrap {iteration}/{b}", flush=True)
    return pd.DataFrame(theta_rows), pd.DataFrame(score_rows), pd.DataFrame(convergence_rows)

def bootstrap_perspective_scores(
    q1: Q1Data,
    boot_score_long: pd.DataFrame,
    stability: dict[str, float],
    perspective: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rank_rows = []
    weight_rows = []
    for iteration, group in boot_score_long.groupby("bootstrap"):
        wide = group.pivot(index="model_id", columns="dimension", values="score")
        synthetic = pd.DataFrame({"model_id": CORE_MODELS})
        for dim in q1.dimensions:
            code = dim_code(dim)
            synthetic[f"{dim}_score"] = synthetic["model_id"].map(wide[code])
        matrix = perspective_matrix(synthetic, q1.dimensions, perspective)
        weights = objective_weights(matrix, stability)
        ranking = rank_matrix(matrix, weights, q1, perspective)
        ranking["bootstrap"] = int(iteration)
        rank_rows.append(ranking[["bootstrap", "model_id", "overall_score", "rank"]])
        weights = weights.copy()
        weights["bootstrap"] = int(iteration)
        weight_rows.append(weights)
    return pd.concat(rank_rows, ignore_index=True), pd.concat(weight_rows, ignore_index=True)

def bootstrap_summary(boot: pd.DataFrame, main: pd.DataFrame, q1: Q1Data, perspective: str) -> pd.DataFrame:
    main_map = main.set_index("model_id")
    rows = []
    for model_id, group in boot.groupby("model_id"):
        rows.append(
            {
                "perspective": perspective,
                "model_id": model_id,
                "model": q1.model_names[model_id],
                "main_score": main_map.loc[model_id, "overall_score"],
                "main_rank": int(main_map.loc[model_id, "rank"]),
                "score_ci_low": group["overall_score"].quantile(0.025),
                "score_ci_high": group["overall_score"].quantile(0.975),
                "rank_ci_low": group["rank"].quantile(0.025),
                "rank_ci_high": group["rank"].quantile(0.975),
                "median_rank": group["rank"].median(),
                "top3_probability": float((group["rank"] <= 3).mean()),
            }
        )
    return pd.DataFrame(rows).sort_values("main_rank")

def old_stability_audit(q1: Q1Data) -> pd.DataFrame:
    path = ROOT / "outputs" / "q1" / "bootstrap" / "bootstrap_dimension_scores_preliminary.csv"
    rows = []
    if path.exists():
        old = pd.read_csv(path)
        for dim in q1.dimensions:
            col = f"{dim}_score"
            sd = old.groupby("model_id")[col].std().dropna()
            vectors = old.pivot(index="bootstrap", columns="model_id", values=col).drop_duplicates()
            endpoint = old.groupby("model_id")[col].apply(lambda x: float(((x == 0) | (x == 100)).mean())).dropna()
            rows.append(
                {
                    "dimension": dim_code(dim),
                    "old_median_score_sd": float(sd.median()) if len(sd) else np.nan,
                    "old_unique_bootstrap_score_vectors": int(len(vectors)),
                    "old_median_endpoint_frequency": float(endpoint.median()) if len(endpoint) else np.nan,
                    "audit_conclusion": "PSEUDO_STABLE_RESAMPLING_DEGENERACY" if len(vectors) == 1 else "VARIATION_PRESENT",
                }
            )
    return pd.DataFrame(rows)

def family_screening_table(q1: Q1Data, corr: pd.DataFrame, common_n: pd.DataFrame, base_pairwise: pd.DataFrame) -> pd.DataFrame:
    manifest = q1.manifest.copy()
    registry = pd.read_csv(FROZEN_DIR / "source_registry_v1.0.csv")
    source_titles = registry.set_index("source_id")["source_title"].to_dict()
    baseline_active = {}
    for dim in q1.dimensions:
        baseline_active[dim_code(dim)] = set(
            base_pairwise.loc[base_pairwise["dimension"] == dim, ["model_i", "model_j"]].stack().unique()
        )
    rows = []
    for (dimension, family), group in manifest.groupby(["dimension", "benchmark_family"], sort=False):
        vals = corr.loc[family].drop(labels=[family], errors="ignore").abs().dropna()
        if len(vals):
            partner = vals.idxmax()
            max_abs = float(vals.loc[partner])
            n = int(common_n.loc[family, partner])
        else:
            partner, max_abs, n = "NONE", np.nan, 0
        removed = base_pairwise[base_pairwise["benchmark_family"] != family]
        dim_removed = removed[removed["dimension"] == dimension]
        graph = graph_diagnostics(dim_removed, CORE_MODELS)
        active_after = set(graph["active_models"])
        indispensable = active_after != baseline_active[dim_code(dimension)] or not graph["connected"]
        semantic = "; ".join(group["benchmark_name"].astype(str).drop_duplicates())
        sources = group["source"].astype(str).drop_duplicates().tolist()
        source_text = "; ".join(f"{s}: {source_titles.get(s, s)}" for s in sources)
        coverage = float(group["model_coverage"].astype(float).mean())
        if indispensable:
            decision = "KEEP_STRUCTURALLY_INDISPENSABLE"
            reason = "Removal changes the active comparison network or its connectivity."
        elif np.isfinite(max_abs) and max_abs >= 0.85:
            decision = "KEEP_REDUNDANCY_FLAG_SENSITIVITY_DELETE"
            reason = (
                "High correlation is not deletion proof; common_n is small or semantic/source roles differ."
                if n <= 3
                else "Retained for semantic/source independence and tested by LOFO."
            )
        else:
            decision = "KEEP_KEY_INDICATOR"
            reason = "Provides nonredundant semantic evidence with adequate network support."
        rows.append(
            {
                "dimension": dim_code(dimension),
                "benchmark_family": family,
                "model_coverage": coverage,
                "max_abs_spearman": max_abs,
                "most_correlated_family": partner,
                "common_n": n,
                "semantic_role": semantic,
                "network_role": "structurally indispensable" if indispensable else "supporting/redundant-tested",
                "source": source_text,
                "decision": decision,
                "reason": reason,
            }
        )
    return pd.DataFrame(rows)

def scenario_analysis(
    q1: Q1Data,
    main: dict[str, Any],
    ranking_a: pd.DataFrame,
    stability_a: dict[str, float],
    mode: str,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    baseline_active = {}
    for dim in q1.dimensions:
        pw = main["pairwise"][main["pairwise"]["dimension"] == dim]
        baseline_active[dim] = set(pw[["model_i", "model_j"]].stack().unique())
    if mode == "LOFO":
        scenarios = [(family, {"families": {family}}) for family in q1.families]
    else:
        scenarios = [
            ("LiveBench", {"source_ids": {"SRC006"}}),
            ("Artificial Analysis", {"source_ids": {"SRC014", "SRC016", "SRC017", "SRC018"}}),
            ("Kimi official/technical comparison", {"source_ids": {"SRC001"}}),
            ("DeepSeek technical report", {"source_ids": {"SRC003"}}),
            ("OpenRouter", {"source_ids": {"SRC007"}}),
        ]
    summary_rows, model_rows, dim_rows = [], [], []
    for scenario, spec in scenarios:
        long = q1.long.copy()
        if "families" in spec:
            long = long[~long["benchmark_family"].isin(spec["families"])].copy()
        else:
            long = long[~long["source_id"].isin(spec["source_ids"])].copy()
        result = fit_main(q1, long)
        valid = True
        for dim in q1.dimensions:
            pw = result["pairwise"][result["pairwise"]["dimension"] == dim]
            graph = graph_diagnostics(pw, CORE_MODELS)
            active = set(graph["active_models"])
            status = "OK"
            if active != baseline_active[dim] or not graph["connected"] or not result["diag"][dim]["converged"]:
                status = "NETWORK_DISCONNECTED"
                valid = False
            base_dim = main["scores"].set_index("model_id").get(f"{dim}_score")
            scenario_dim = result["scores"].set_index("model_id").get(f"{dim}_score")
            score_delta = np.nan
            if base_dim is not None and scenario_dim is not None:
                common = base_dim.index.intersection(scenario_dim.index)
                if len(common):
                    score_delta = float((scenario_dim.loc[common] - base_dim.loc[common]).abs().mean())
            dim_rows.append(
                {
                    "analysis": mode,
                    "removed": scenario,
                    "dimension": dim_code(dim),
                    "status": status,
                    "active_models": len(active),
                    "baseline_active_models": len(baseline_active[dim]),
                    "connected": graph["connected"],
                    "bt_converged": result["diag"][dim]["converged"],
                    "mean_abs_dimension_score_change": score_delta,
                }
            )
        if valid:
            matrix = perspective_matrix(result["scores"], q1.dimensions, "A")
            weights = objective_weights(matrix, stability_a)
            ranking = rank_matrix(matrix, weights, q1, "A")
            comp = rank_comparison(ranking_a, ranking, scenario)
            status = "OK"
            for row in ranking.itertuples(index=False):
                main_rank = int(ranking_a.loc[ranking_a["model_id"] == row.model_id, "rank"].iloc[0])
                model_rows.append(
                    {
                        "analysis": mode,
                        "removed": scenario,
                        "status": status,
                        "model_id": row.model_id,
                        "model": row.model,
                        "main_rank": main_rank,
                        "scenario_rank": int(row.rank),
                        "rank_change": int(row.rank) - main_rank,
                        "scenario_score": row.overall_score,
                    }
                )
            summary_rows.append({"analysis": mode, "removed": scenario, "status": status, **comp})
        else:
            summary_rows.append(
                {
                    "analysis": mode,
                    "removed": scenario,
                    "status": "NETWORK_DISCONNECTED",
                    "comparison": scenario,
                    "common_models": np.nan,
                    "spearman": np.nan,
                    "kendall_tau": np.nan,
                    "kimi_rank_A": int(ranking_a.loc[ranking_a["model_id"] == KIMI_MODEL_ID, "rank"].iloc[0]),
                    "kimi_rank_other": np.nan,
                    "top3_overlap_count": np.nan,
                    "top3_membership_A": "; ".join(ranking_a.nsmallest(3, "rank")["model_id"]),
                    "top3_membership_other": "NETWORK_DISCONNECTED",
                }
            )
    return pd.DataFrame(summary_rows), pd.DataFrame(model_rows), pd.DataFrame(dim_rows)

def equal_weight_table(
    q1: Q1Data,
    matrix: pd.DataFrame,
    objective_ranking: pd.DataFrame,
    perspective: str,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    equal = pd.DataFrame({"dimension": matrix.columns, "weight": [1.0 / len(matrix.columns)] * len(matrix.columns)})
    equal["information_I"] = np.nan
    equal["non_redundancy_R"] = np.nan
    equal["latent_rank_stability_T"] = np.nan
    equal["q"] = np.nan
    equal_rank = rank_matrix(matrix, equal, q1, f"{perspective}_EQUAL")
    merged = objective_ranking[["model_id", "model", "rank", "overall_score"]].merge(
        equal_rank[["model_id", "rank", "overall_score"]], on="model_id", suffixes=("_main", "_equal")
    )
    merged = merged.rename(
        columns={
            "rank_main": "main_rank",
            "rank_equal": "equal_weight_rank",
            "overall_score_main": "main_score",
            "overall_score_equal": "equal_weight_score",
        }
    )
    merged["rank_change"] = merged["equal_weight_rank"] - merged["main_rank"]
    merged["perspective"] = perspective
    comp = rank_comparison(objective_ranking, equal_rank, f"{perspective}: objective vs equal")
    return merged, comp
